Advanced LC-3b Simulator Development

Project Overview:
Developed a comprehensive LC-3b simulator through three phases of enhancement, culminating in advanced features for virtual memory management and robust exception handling.

Version 1: Basic LC-3b Simulator

Key Features:
- Implemented fundamental simulator functionalities, including instruction execution and branching support.
- Developed basic debugging features to facilitate instruction tracing and error detection.
- Established the foundation for subsequent enhancements in the simulator architecture.

Version 2: Enhanced Simulator with Interrupt Handling

Key Enhancements:
- Added support for interrupt handling to manage external events and interruptions.
- Expanded functionality to include nested interrupts and prioritize interrupt servicing.
- Refined instruction execution and branching capabilities for improved simulator performance.

Version 3: Advanced Simulator with Virtual Memory and Exception Handling

Key Accomplishments:
- Virtual Memory Implementation:
  - Extended the simulator to support virtual memory with a one-level page table translation scheme.
  - Introduced new datapath elements, including the Page Table Base Register (PTBR) and Virtual Address Register (VA).
  - Implemented address translation, managed page faults, and updated page table entries (PTEs) for protection and reference bit handling.

- Exception Handling:
  - Integrated support for four types of exceptions: unaligned access, protection, page fault, and unknown opcode.
  - Designed and implemented mechanisms for detecting and handling these exceptions with appropriate priorities.

- Datapath and State Diagram Enhancements:
  - Modified the datapath to include new registers and control signals for virtual memory operations.
  - Updated the state diagram to add states for address translation and exception handling, ensuring integration with existing states.

- Microsequencer Modifications:
  - Augmented the microsequencer to support new control signals and state transitions.
  - Enhanced logic for managing the return to the correct state after address translation.

- Testing and Validation:
  - Conducted extensive testing with various scenarios, including user programs, interrupt/exception handling, and virtual memory operations.
  - Generated and analyzed dumps of memory and registers to ensure accuracy.

- Documentation and Code Quality:
  - Developed detailed documentation for changes to the datapath, state diagram, microsequencer, and control signals.
  - Provided comprehensive source code comments and explanations in lc3bsim5.c and other relevant files.
  - Submitted a complete set of assembly files and control store configurations.

Technologies and Tools:
- LC-3b Simulator
- Assembly Language
- Microcode and Control Store
- Excel and PDF for design documentation

Outcome:
Successfully delivered a fully functional LC-3b simulator with advanced virtual memory support and robust exception handling, demonstrating a deep understanding of microarchitecture and system-level design.
