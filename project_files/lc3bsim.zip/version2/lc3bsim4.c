#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/***************************************************************/
/*                                                             */
/* Files:  ucode        Microprogram file                      */
/*         isaprogram   LC-3b machine language program file    */
/*                                                             */
/***************************************************************/

/***************************************************************/
/* These are the functions you'll have to write.               */
/***************************************************************/

void eval_micro_sequencer();
void cycle_memory();
void eval_bus_drivers();
void drive_bus();
void latch_datapath_values();

/***************************************************************/
/* A couple of useful definitions.                             */
/***************************************************************/
#define FALSE 0
#define TRUE  1

/***************************************************************/
/* Use this to avoid overflowing 16 bits on the bus.           */
/***************************************************************/
#define Low16bits(x) ((x) & 0xFFFF)

/***************************************************************/
/* Definition of the control store layout.                     */
/***************************************************************/
#define CONTROL_STORE_ROWS 64
#define INITIAL_STATE_NUMBER 18

/***************************************************************/
/* Definition of bit order in control store word.              */
/***************************************************************/
enum CS_BITS {                                                  
    IRD,
    COND1, COND0,   
    J5, J4, J3, J2, J1, J0,
    LD_MAR,
    LD_MDR,
    LD_IR,
    LD_BEN,
    LD_REG,
    LD_CC,
    LD_PC,
    GATE_PC,
    GATE_MDR,
    GATE_ALU,
    GATE_MARMUX,
    GATE_SHF,
    PCMUX1, PCMUX0,
    DRMUX,  
    SR1MUX,  
    ADDR1MUX,
    ADDR2MUX1, ADDR2MUX0,
    MARMUX,
    ALUK1, ALUK0,
    MIO_EN,
    R_W,
    DATA_SIZE,
    LSHF1,
/* MODIFY: you have to add all your new control signals */
    LD_SAVESSP,
    LD_SAVEUSP,
    LD_VEC,
    LD_PRIV,
    GATE_SP,
    GATE_VEC,
    GATE_PSR,
    GATE_PCDEC,
    COND2,
    DRMUX1,
    SR1MUX1,
    SPMUX0, SPMUX1,
    VECMUX,
    PSRMUX,
    CONTROL_STORE_BITS
} CS_BITS;

/***************************************************************/
/* Functions to get at the control bits.                       */
/***************************************************************/
int GetIRD(int *x)           { return(x[IRD]); }
int GetCOND(int *x)          { return((x[COND1] << 1) + x[COND0]); }
int GetJ(int *x)             { return((x[J5] << 5) + (x[J4] << 4) +
				      (x[J3] << 3) + (x[J2] << 2) +
				      (x[J1] << 1) + x[J0]); }
int GetLD_MAR(int *x)        { return(x[LD_MAR]); }
int GetLD_MDR(int *x)        { return(x[LD_MDR]); }
int GetLD_IR(int *x)         { return(x[LD_IR]); }
int GetLD_BEN(int *x)        { return(x[LD_BEN]); }
int GetLD_REG(int *x)        { return(x[LD_REG]); }
int GetLD_CC(int *x)         { return(x[LD_CC]); }
int GetLD_PC(int *x)         { return(x[LD_PC]); }
int GetGATE_PC(int *x)       { return(x[GATE_PC]); }
int GetGATE_MDR(int *x)      { return(x[GATE_MDR]); }
int GetGATE_ALU(int *x)      { return(x[GATE_ALU]); }
int GetGATE_MARMUX(int *x)   { return(x[GATE_MARMUX]); }
int GetGATE_SHF(int *x)      { return(x[GATE_SHF]); }
int GetPCMUX(int *x)         { return((x[PCMUX1] << 1) + x[PCMUX0]); }
int GetDRMUX(int *x)         { return(x[DRMUX]); }
// int GetDRMUX(int *x)         { return((x[DRMUX1] << 1) + x[DRMUX]); }  // returns sum
int GetSR1MUX(int *x)        { return(x[SR1MUX]); }
// int GetSR1MUX(int *x)        { return((x[SR1MUX1] << 1) + x[SR1MUX]); }  // returns sum
int GetADDR1MUX(int *x)      { return(x[ADDR1MUX]); }
int GetADDR2MUX(int *x)      { return((x[ADDR2MUX1] << 1) + x[ADDR2MUX0]); }
int GetMARMUX(int *x)        { return(x[MARMUX]); }
int GetALUK(int *x)          { return((x[ALUK1] << 1) + x[ALUK0]); }
int GetMIO_EN(int *x)        { return(x[MIO_EN]); }
int GetR_W(int *x)           { return(x[R_W]); }
int GetDATA_SIZE(int *x)     { return(x[DATA_SIZE]); } 
int GetLSHF1(int *x)         { return(x[LSHF1]); }

/* MODIFY: you can add more Get functions for your new control signals */
int GetDRMUX1(int *x)         { return(x[DRMUX1]); }
int GetSR1MUX1(int *x)        { return(x[SR1MUX1]); }
int GetLD_SAVESSP(int *x)     { return(x[LD_SAVESSP]); }
int GetLD_SAVEUSP(int *x)     { return(x[LD_SAVEUSP]); }
int GetLD_VEC(int *x)         { return(x[LD_VEC]); }
int GetLD_PRIV(int *x)        { return(x[LD_PRIV]); }
int GetGATE_SP(int *x)        { return(x[GATE_SP]); }
int GetGATE_VEC(int *x)       { return(x[GATE_VEC]); }
int GetGATE_PSR(int *x)       { return(x[GATE_PSR]); }
int GetGATE_PCDEC(int *x)     { return(x[GATE_PCDEC]); }
int GetSPMUX(int *x)         { return((x[SPMUX1] << 1) + x[SPMUX0]); }  // returns sum
// int GetSPMUX0(int *x)        { return(x[SPMUX0]); }
int GetVECMUX(int *x)        { return(x[VECMUX]); }
int GetPSRMUX(int *x)        { return(x[PSRMUX]); }


/***************************************************************/
/* The control store rom.                                      */
/***************************************************************/
int CONTROL_STORE[CONTROL_STORE_ROWS][CONTROL_STORE_BITS];

/***************************************************************/
/* Main memory.                                                */
/***************************************************************/
/* MEMORY[A][0] stores the least significant byte of word at word address A
   MEMORY[A][1] stores the most significant byte of word at word address A 
   There are two write enable signals, one for each byte. WE0 is used for 
   the least significant byte of a word. WE1 is used for the most significant 
   byte of a word. */

#define WORDS_IN_MEM    0x08000 
#define MEM_CYCLES      5
int MEMORY[WORDS_IN_MEM][2];

/***************************************************************/

/***************************************************************/

/***************************************************************/
/* LC-3b State info.                                           */
/***************************************************************/
#define LC_3b_REGS 8

int RUN_BIT;	/* run bit */
int BUS;	/* value of the bus */

typedef struct System_Latches_Struct{

int PC,		/* program counter */
    MDR,	/* memory data register */
    MAR,	/* memory address register */
    IR,		/* instruction register */
    N,		/* n condition bit */
    Z,		/* z condition bit */
    P,		/* p condition bit */
    PRIV,   /*Additional*/
    BEN;        /* ben register */

int READY;	/* ready bit */
  /* The ready bit is also latched as you dont want the memory system to assert it 
     at a bad point in the cycle*/

int REGS[LC_3b_REGS]; /* register file. */

int MICROINSTRUCTION[CONTROL_STORE_BITS]; /* The microintruction */

int STATE_NUMBER; /* Current State Number - Provided for debugging */ 

/* For lab 4 */
int INTV; /* Interrupt vector register */
int EXCV; /* Exception vector register */
int SSP; /* Initial value of system stack pointer */

/* MODIFY: You may add system latches that are required by your implementation */
int USP; 
int INT; /* interrupt control signal*/
int EXC; /*exception control signal*/
int PSR; /* program status register*/
int VEC; 

} System_Latches;

/* Data Structure for Latch */

System_Latches CURRENT_LATCHES, NEXT_LATCHES;

/***************************************************************/
/* A cycle counter.                                            */
/***************************************************************/
int CYCLE_COUNT;

/***************************************************************/
/*                                                             */
/* Procedure : help                                            */
/*                                                             */
/* Purpose   : Print out a list of commands.                   */
/*                                                             */
/***************************************************************/
void help() {                                                    
    printf("----------------LC-3bSIM Help-------------------------\n");
    printf("go               -  run program to completion       \n");
    printf("run n            -  execute program for n cycles    \n");
    printf("mdump low high   -  dump memory from low to high    \n");
    printf("rdump            -  dump the register & bus values  \n");
    printf("?                -  display this help menu          \n");
    printf("quit             -  exit the program                \n\n");
}

/***************************************************************/
/*                                                             */
/* Procedure : cycle                                           */
/*                                                             */
/* Purpose   : Execute a cycle                                 */
/*                                                             */
/***************************************************************/
int global_INT = 0; 
void cycle() {                         
  if (CYCLE_COUNT == 300) {
    // CURRENT_LATCHES.INT = 1;
    // CURRENT_LATCHES.INTV = 0x01;
    NEXT_LATCHES.INT = 1;
    NEXT_LATCHES.INTV = 0x01;
    global_INT = 1; 

    // setting priv/psr[15] bits
    // NEXT_LATCHES.PRIV = 0; 
    // NEXT_LATCHES.PSR = CURRENT_LATCHES.PSR & 0xFFFF7FFF; 
  }
  eval_micro_sequencer();   
  cycle_memory();
  eval_bus_drivers();
  drive_bus();
  latch_datapath_values();  // exceptions checked here
//   eval_micro_sequencer();   

  CURRENT_LATCHES = NEXT_LATCHES;

  CYCLE_COUNT++;
//   if (CYCLE_COUNT == 299) {
//      NEXT_LATCHES.INT = 1;
//      NEXT_LATCHES.INTV = 0x01;
//      global_INT = 1; 
//   }
}

/***************************************************************/
/*                                                             */
/* Procedure : run n                                           */
/*                                                             */
/* Purpose   : Simulate the LC-3b for n cycles.                 */
/*                                                             */
/***************************************************************/
void run(int num_cycles) {                                      
    int i;

    if (RUN_BIT == FALSE) {
	printf("Can't simulate, Simulator is halted\n\n");
	return;
    }

    printf("Simulating for %d cycles...\n\n", num_cycles);
    for (i = 0; i < num_cycles; i++) {
	if (CURRENT_LATCHES.PC == 0x0000) {
	    RUN_BIT = FALSE;
	    printf("Simulator halted\n\n");
	    break;
	}
	cycle();
    }
}

/***************************************************************/
/*                                                             */
/* Procedure : go                                              */
/*                                                             */
/* Purpose   : Simulate the LC-3b until HALTed.                 */
/*                                                             */
/***************************************************************/
void go() {                                                     
    if (RUN_BIT == FALSE) {
	printf("Can't simulate, Simulator is halted\n\n");
	return;
    }

    printf("Simulating...\n\n");
    while (CURRENT_LATCHES.PC != 0x0000)
	cycle();
    RUN_BIT = FALSE;
    printf("Simulator halted\n\n");
}

/***************************************************************/ 
/*                                                             */
/* Procedure : mdump                                           */
/*                                                             */
/* Purpose   : Dump a word-aligned region of memory to the     */
/*             output file.                                    */
/*                                                             */
/***************************************************************/
void mdump(FILE * dumpsim_file, int start, int stop) {          
    int address; /* this is a byte address */

    printf("\nMemory content [0x%0.4x..0x%0.4x] :\n", start, stop);
    printf("-------------------------------------\n");
    for (address = (start >> 1); address <= (stop >> 1); address++)
	printf("  0x%0.4x (%d) : 0x%0.2x%0.2x\n", address << 1, address << 1, MEMORY[address][1], MEMORY[address][0]);
    printf("\n");

    /* dump the memory contents into the dumpsim file */
    fprintf(dumpsim_file, "\nMemory content [0x%0.4x..0x%0.4x] :\n", start, stop);
    fprintf(dumpsim_file, "-------------------------------------\n");
    for (address = (start >> 1); address <= (stop >> 1); address++)
	fprintf(dumpsim_file, " 0x%0.4x (%d) : 0x%0.2x%0.2x\n", address << 1, address << 1, MEMORY[address][1], MEMORY[address][0]);
    fprintf(dumpsim_file, "\n");
    fflush(dumpsim_file);
}

/***************************************************************/
/*                                                             */
/* Procedure : rdump                                           */
/*                                                             */
/* Purpose   : Dump current register and bus values to the     */   
/*             output file.                                    */
/*                                                             */
/***************************************************************/
void rdump(FILE * dumpsim_file) {                               
    int k; 

    printf("\nCurrent register/bus values :\n");
    printf("-------------------------------------\n");
    printf("Cycle Count  : %d\n", CYCLE_COUNT);
    printf("PC           : 0x%0.4x\n", CURRENT_LATCHES.PC);
    printf("IR           : 0x%0.4x\n", CURRENT_LATCHES.IR);
    printf("STATE_NUMBER : 0x%0.4x\n\n", CURRENT_LATCHES.STATE_NUMBER);
    printf("BUS          : 0x%0.4x\n", BUS);
    printf("MDR          : 0x%0.4x\n", CURRENT_LATCHES.MDR);
    printf("MAR          : 0x%0.4x\n", CURRENT_LATCHES.MAR);
    printf("CCs: N = %d  Z = %d  P = %d\n", CURRENT_LATCHES.N, CURRENT_LATCHES.Z, CURRENT_LATCHES.P);
    printf("Registers:\n");
    for (k = 0; k < LC_3b_REGS; k++)
	printf("%d: 0x%0.4x\n", k, CURRENT_LATCHES.REGS[k]);
    printf("\n");

    /* dump the state information into the dumpsim file */
    fprintf(dumpsim_file, "\nCurrent register/bus values :\n");
    fprintf(dumpsim_file, "-------------------------------------\n");
    fprintf(dumpsim_file, "Cycle Count  : %d\n", CYCLE_COUNT);
    fprintf(dumpsim_file, "PC           : 0x%0.4x\n", CURRENT_LATCHES.PC);
    fprintf(dumpsim_file, "IR           : 0x%0.4x\n", CURRENT_LATCHES.IR);
    fprintf(dumpsim_file, "STATE_NUMBER : 0x%0.4x\n\n", CURRENT_LATCHES.STATE_NUMBER);
    fprintf(dumpsim_file, "BUS          : 0x%0.4x\n", BUS);
    fprintf(dumpsim_file, "MDR          : 0x%0.4x\n", CURRENT_LATCHES.MDR);
    fprintf(dumpsim_file, "MAR          : 0x%0.4x\n", CURRENT_LATCHES.MAR);
    fprintf(dumpsim_file, "CCs: N = %d  Z = %d  P = %d\n", CURRENT_LATCHES.N, CURRENT_LATCHES.Z, CURRENT_LATCHES.P);
    fprintf(dumpsim_file, "Registers:\n");
    for (k = 0; k < LC_3b_REGS; k++)
	fprintf(dumpsim_file, "%d: 0x%0.4x\n", k, CURRENT_LATCHES.REGS[k]);
    fprintf(dumpsim_file, "\n");
    fflush(dumpsim_file);
}

/***************************************************************/
/*                                                             */
/* Procedure : get_command                                     */
/*                                                             */
/* Purpose   : Read a command from standard input.             */  
/*                                                             */
/***************************************************************/
void get_command(FILE * dumpsim_file) {                         
    char buffer[20];
    int start, stop, cycles;

    printf("LC-3b-SIM> ");

    scanf("%s", buffer);
    printf("\n");

    switch(buffer[0]) {
    case 'G':
    case 'g':
	go();
	break;

    case 'M':
    case 'm':
	scanf("%i %i", &start, &stop);
	mdump(dumpsim_file, start, stop);
	break;

    case '?':
	help();
	break;
    case 'Q':
    case 'q':
	printf("Bye.\n");
	exit(0);

    case 'R':
    case 'r':
	if (buffer[1] == 'd' || buffer[1] == 'D')
	    rdump(dumpsim_file);
	else {
	    scanf("%d", &cycles);
	    run(cycles);
	}
	break;

    default:
	printf("Invalid Command\n");
	break;
    }
}

/***************************************************************/
/*                                                             */
/* Procedure : init_control_store                              */
/*                                                             */
/* Purpose   : Load microprogram into control store ROM        */ 
/*                                                             */
/***************************************************************/
void init_control_store(char *ucode_filename) {                 
    FILE *ucode;
    int i, j, index;
    char line[200];

    printf("Loading Control Store from file: %s\n", ucode_filename);

    /* Open the micro-code file. */
    if ((ucode = fopen(ucode_filename, "r")) == NULL) {
	printf("Error: Can't open micro-code file %s\n", ucode_filename);
	exit(-1);
    }

    /* Read a line for each row in the control store. */
    for(i = 0; i < CONTROL_STORE_ROWS; i++) {
	if (fscanf(ucode, "%[^\n]\n", line) == EOF) {
	    printf("Error: Too few lines (%d) in micro-code file: %s\n",
		   i, ucode_filename);
	    exit(-1);
	}

	/* Put in bits one at a time. */
	index = 0;

	for (j = 0; j < CONTROL_STORE_BITS; j++) {
	    /* Needs to find enough bits in line. */
	    if (line[index] == '\0') {
		printf("Error: Too few control bits in micro-code file: %s\nLine: %d\n",
		       ucode_filename, i);
		exit(-1);
	    }
	    if (line[index] != '0' && line[index] != '1') {
		printf("Error: Unknown value in micro-code file: %s\nLine: %d, Bit: %d\n",
		       ucode_filename, i, j);
		exit(-1);
	    }

	    /* Set the bit in the Control Store. */
	    CONTROL_STORE[i][j] = (line[index] == '0') ? 0:1;
	    index++;
	}

	/* Warn about extra bits in line. */
	if (line[index] != '\0')
	    printf("Warning: Extra bit(s) in control store file %s. Line: %d\n",
		   ucode_filename, i);
    }
    printf("\n");
}

/***************************************************************/
/*                                                             */
/* Procedure : init_memory                                     */
/*                                                             */
/* Purpose   : Zero out the memory array                       */
/*                                                             */
/***************************************************************/
void init_memory() {                                           
    int i;

    for (i=0; i < WORDS_IN_MEM; i++) {
	MEMORY[i][0] = 0;
	MEMORY[i][1] = 0;
    }
}

/**************************************************************/
/*                                                            */
/* Procedure : load_program                                   */
/*                                                            */
/* Purpose   : Load program and service routines into mem.    */
/*                                                            */
/**************************************************************/
void load_program(char *program_filename) {                   
    FILE * prog;
    int ii, word, program_base;

    /* Open program file. */
    prog = fopen(program_filename, "r");
    if (prog == NULL) {
	printf("Error: Can't open program file %s\n", program_filename);
	exit(-1);
    }

    /* Read in the program. */
    if (fscanf(prog, "%x\n", &word) != EOF)
	program_base = word >> 1;
    else {
	printf("Error: Program file is empty\n");
	exit(-1);
    }

    ii = 0;
    while (fscanf(prog, "%x\n", &word) != EOF) {
	/* Make sure it fits. */
	if (program_base + ii >= WORDS_IN_MEM) {
	    printf("Error: Program file %s is too long to fit in memory. %x\n",
		   program_filename, ii);
	    exit(-1);
	}

	/* Write the word to memory array. */
	MEMORY[program_base + ii][0] = word & 0x00FF;
	MEMORY[program_base + ii][1] = (word >> 8) & 0x00FF;
	ii++;
    }

    if (CURRENT_LATCHES.PC == 0) CURRENT_LATCHES.PC = (program_base << 1);

    printf("Read %d words from program into memory.\n\n", ii);
}

/***************************************************************/
/*                                                             */
/* Procedure : initialize                                      */
/*                                                             */
/* Purpose   : Load microprogram and machine language program  */ 
/*             and set up initial state of the machine.        */
/*                                                             */
/***************************************************************/
void initialize(char *argv[], int num_prog_files) { 
    int i;
    init_control_store(argv[1]);

    init_memory();
    for ( i = 0; i < num_prog_files; i++ ) {
	load_program(argv[i + 2]);
    }
    CURRENT_LATCHES.Z = 1;
    CURRENT_LATCHES.PRIV = 1; 
    CURRENT_LATCHES.STATE_NUMBER = INITIAL_STATE_NUMBER;
    memcpy(CURRENT_LATCHES.MICROINSTRUCTION, CONTROL_STORE[INITIAL_STATE_NUMBER], sizeof(int)*CONTROL_STORE_BITS);
    CURRENT_LATCHES.SSP = 0x3000; /* Initial value of system stack pointer */; 
    CURRENT_LATCHES.USP = 0xFE00; /* Initial value of user stack pointer */; 
    CURRENT_LATCHES.REGS[6] = 0xFE00;

    // added interrupt reset
    CURRENT_LATCHES.INT = 0; 
    // added initialize PSR : user privilege + z bit
    CURRENT_LATCHES.PSR = 0x8002;  
    // added privlege mode to user
    CURRENT_LATCHES.PRIV = 1; 

    NEXT_LATCHES = CURRENT_LATCHES;

    RUN_BIT = TRUE;
}

/***************************************************************/
/*                                                             */
/* Procedure : main                                            */
/*                                                             */
/***************************************************************/
int main(int argc, char *argv[]) {                              
    FILE * dumpsim_file;

    /* Error Checking */
    if (argc < 3) {
	printf("Error: usage: %s <micro_code_file> <program_file_1> <program_file_2> ...\n",
	       argv[0]);
	exit(1);
    }

    printf("LC-3b Simulator\n\n");

    initialize(argv, argc - 2);

    if ( (dumpsim_file = fopen( "dumpsim", "w" )) == NULL ) {
	printf("Error: Can't open dumpsim file\n");
	exit(-1);
    }

    while (1)
	get_command(dumpsim_file);

}

/***************************************************************/
/* Do not modify the above code, except for the places indicated 
   with a "MODIFY:" comment.

   Do not modify the rdump and mdump functions.

   You are allowed to use the following global variables in your
   code. These are defined above.

   CONTROL_STORE
   MEMORY
   BUS

   CURRENT_LATCHES
   NEXT_LATCHES

   You may define your own local/global variables and functions.
   You may use the functions to get at the control bits defined
   above.

   Begin your code here 	  			       */
/***************************************************************/
    // gcc -std=c99 -o lc3bsim4 lc3bsim4.c
    // gcc -g -std=c99 -o lc3bsim4 lc3bsim4.c
    // ./lc3bsim4 ucode4 add.obj int.obj vector_table.obj except_prot.obj except_unaligned.obj except_unknown.obj data.obj
    // ./lc3bsim4 ucode4 test.obj int.obj vector_table.obj except_prot.obj except_unaligned.obj except_unknown.obj data.obj

int signExtend(int num, int bitsNum) {
    int msb = (num >> (bitsNum - 1) & 0x01);
    int mask = (0xFFFF << bitsNum);
    if (msb) return ((num | mask) & 0xFFFF);
    else return num;
}

int flagException() {
    // Protection Exception
    if ((CURRENT_LATCHES.PRIV == 1) && // user mode
        (GetLD_MAR(CURRENT_LATCHES.MICROINSTRUCTION) == 1) && // load MAR
        (Low16bits(BUS) < 0x3000)) { // memory address on bus
        NEXT_LATCHES.EXCV = 0x02; 
        return 1; 
    }

    // Unaligned Access
    else if((GetDATA_SIZE(CURRENT_LATCHES.MICROINSTRUCTION) == 1) && 
            (GetLD_MAR(CURRENT_LATCHES.MICROINSTRUCTION) == 1) &&
            (Low16bits(BUS % 2) == 1) && 
            (CURRENT_LATCHES.PRIV != 0)) {
            NEXT_LATCHES.EXCV = 0x03;
            return 1;
    }
    

    // Unknown Opcode
    if ((((CURRENT_LATCHES.IR >> 12) & 0xF) == 0xA) // opcode 1010
    || (((CURRENT_LATCHES.IR >> 12) & 0xF) == 0xB)) { // opcode 1011
        NEXT_LATCHES.EXCV = 0x04; 
        return 1;
    }
    
    return 0;
}
int excFlag; 
void eval_micro_sequencer() {
    /*
     * Evaluate the address of the next state according to the
     * micro sequencer logic. Latch the next microinstruction.
     */
    int next_state = -1;
    int j = GetJ(CURRENT_LATCHES.MICROINSTRUCTION);
    int cond = GetCOND(CURRENT_LATCHES.MICROINSTRUCTION);
    
    if (global_INT && CURRENT_LATCHES.STATE_NUMBER == 18) { // finish current instruction before interrupt
        next_state = 41;
    }
    else if (CURRENT_LATCHES.STATE_NUMBER == 11) {  // exception
        next_state = 41;   
    }
    else if (GetIRD(CURRENT_LATCHES.MICROINSTRUCTION)) {  // '00' + IR[15:12]
        next_state = (CURRENT_LATCHES.IR >> 12) & 0xF;
    } 
    else { // microsequencer logic
        int cond0 = cond & 0x1;
        int cond1 = (cond & 0x2) >> 1;
        int cond2 = (cond & 0x4) >> 1;

        // Privilege > cond2 & !cond1 & cond0 & PSR[15]
        int j4 = ((j & 0x10) >> 4) | (cond2 && !cond1 && cond0 && CURRENT_LATCHES.PRIV);       

        // Interrupt > cond2 & !cond1 & !cond 0 & INT
        int j3 = ((j & 0x8) >> 3) | (cond2 && !cond1 && !cond0 && CURRENT_LATCHES.INT);       

        // Branch > !cond2 & cond1 & !cond0 & BEN
        int j2 = ((j & 0x4) >> 2) | (!cond2 && cond1 && !cond0 && CURRENT_LATCHES.BEN);       
        
        // Ready > !cond2 &* !cond1 & cond0 & R
        int j1 = ((j & 0x2) >> 1) | (!cond2 && !cond1 && cond0 && CURRENT_LATCHES.READY);
        
        // Addr.Mode > cond1 & cond0 & IR[11]
        int j0 = (j & 0x1) | (((CURRENT_LATCHES.IR & 0x800) >> 11) && cond0 && cond1 && !cond2);

        // j5 + j4 + j3 + j2 + j1 + j0
        next_state = (j & 0x20) + (j4 << 4) + (j3 << 3) + (j2 << 2) + (j1 << 1) + j0;
    }
    NEXT_LATCHES.STATE_NUMBER = next_state;
    memcpy(NEXT_LATCHES.MICROINSTRUCTION, CONTROL_STORE[next_state], sizeof(int) * CONTROL_STORE_BITS);
}


int count_cycle; 
int read_result;
void cycle_memory() {
    /*
    * This function emulates memory and the WE logic.
    * Keep track of which cycle of count_cycle we are dealing with.  
    * If fourth, we need to latch Ready bit at the end of
    * cycle to prepare microsequencer for the fifth cycle.  
    */

    // depends on MAR[0], R.W, and DATA.SIZE
    int MAR_b0 = (CURRENT_LATCHES.MAR & 0x1);
    int R_W = GetR_W(CURRENT_LATCHES.MICROINSTRUCTION);
    int DATA_SIZE = GetDATA_SIZE(CURRENT_LATCHES.MICROINSTRUCTION);

    if (!GetMIO_EN(CURRENT_LATCHES.MICROINSTRUCTION)) // memory is not accessed in this cycle
        return;

    count_cycle++;
    if (count_cycle == 4) {
        NEXT_LATCHES.READY = 1;
    }

    if (CURRENT_LATCHES.READY == 1) {
        count_cycle = 0;    // reset flag
        NEXT_LATCHES.READY = 0;
        int addr = Low16bits(CURRENT_LATCHES.MAR) >> 1;
        if (R_W == 1) { // write
            if (DATA_SIZE == 0) { // byte
                if (MAR_b0) { // mar[0] = 1
                    MEMORY[addr][1] = CURRENT_LATCHES.MDR & 0xFF;   
                } else { // mar[0] = 0
                    MEMORY[addr][0] = CURRENT_LATCHES.MDR & 0xFF;   
                }
            } else if (DATA_SIZE == 1) {   // word
                MEMORY[addr][0] = CURRENT_LATCHES.MDR & 0xFF;
                MEMORY[addr][1] = (CURRENT_LATCHES.MDR >> 8) & 0xFF;
            }
        } else {
            // Read operation
            read_result = (MEMORY[addr][1] << 8) | MEMORY[addr][0];
        }
    }
}


int marmux_val, alu_val, shf_val, mdr_val, pc_val;
// ADDITIONAL
int pcdec_val, sp_val, temp_val, vec_val, psr_val; 
void eval_bus_drivers() {

    int MARMUX = GetMARMUX(CURRENT_LATCHES.MICROINSTRUCTION);
    int PCMUX = GetPCMUX(CURRENT_LATCHES.MICROINSTRUCTION);
    int SR1MUX = GetSR1MUX(CURRENT_LATCHES.MICROINSTRUCTION);
    int ADDR1MUX = GetADDR1MUX(CURRENT_LATCHES.MICROINSTRUCTION);
    int ADDR2MUX = GetADDR2MUX(CURRENT_LATCHES.MICROINSTRUCTION);
    int ALUK = GetALUK(CURRENT_LATCHES.MICROINSTRUCTION);
    int MIO_EN = GetMIO_EN(CURRENT_LATCHES.MICROINSTRUCTION);
    int R_W = GetR_W(CURRENT_LATCHES.MICROINSTRUCTION);
    int DATA_SIZE = GetDATA_SIZE(CURRENT_LATCHES.MICROINSTRUCTION);
    int LSHF1 = GetLSHF1(CURRENT_LATCHES.MICROINSTRUCTION);

    // Additional
    int SR1MUX1 = GetSR1MUX1(CURRENT_LATCHES.MICROINSTRUCTION);
    int SPMUX = GetSPMUX(CURRENT_LATCHES.MICROINSTRUCTION); // returns SPMUX0 + SPMUX1
    int VECMUX = GetVECMUX(CURRENT_LATCHES.MICROINSTRUCTION);
    int PSRMUX = GetPSRMUX(CURRENT_LATCHES.MICROINSTRUCTION);

    BUS = 0;

// ADDR1MUX
    int addr1_data = 0;
    if (ADDR1MUX == 0) {
        addr1_data = CURRENT_LATCHES.PC;
    }
    else if (ADDR1MUX == 1) {
        int baseR = (CURRENT_LATCHES.IR >> 6) & 0x7;
        addr1_data = CURRENT_LATCHES.REGS[baseR];
    }
   
// ADDR2MUX
    int addr2_data;
    if (ADDR2MUX == 0) {    
        addr2_data = 0;
    }
    else if (ADDR2MUX == 1) { // 10, sext 6
        addr2_data = signExtend(CURRENT_LATCHES.IR & 0x003F, 6);
    }
    else if (ADDR2MUX == 2) { // 8, sext 9
        addr2_data = signExtend(CURRENT_LATCHES.IR & 0x01FF, 9);
    }
    else if (ADDR2MUX == 3) { // 5, sext 11
        addr2_data = signExtend(CURRENT_LATCHES.IR & 0x07FF, 11);
    }

    if (GetLSHF1(CURRENT_LATCHES.MICROINSTRUCTION)) {
        addr2_data = addr2_data << 1;
    }

// Adder
    int adder = addr2_data + addr1_data;

//SR1MUX, SR2
    int SR1;
    int sr1mux_total = (SR1MUX1 << 1) + SR1MUX; 
    if (sr1mux_total == 1)  {
        SR1 = (CURRENT_LATCHES.IR >> 6) & 0x7; // IR[8:6]}
    }
    else if (sr1mux_total == 0) {
        SR1 = (CURRENT_LATCHES.IR >> 9) & 0x7; // IR[11:9]
    }        
    else if (sr1mux_total == 2) {
        SR1 = 6; // R6
    }
    int SR2 = (CURRENT_LATCHES.IR) & 0x7;

// ALU
    if (GetGATE_ALU(CURRENT_LATCHES.MICROINSTRUCTION)) {
        int addressing_mode = (CURRENT_LATCHES.IR >> 5) & 0x1;
        int imm_val = signExtend(CURRENT_LATCHES.IR & 0x1F, 5); // 1-imm, 0-reg

        switch (ALUK) {
            case 0: // ADD
                if (addressing_mode) {
                    alu_val = CURRENT_LATCHES.REGS[SR1] + imm_val;
                }
                else {
                    alu_val = CURRENT_LATCHES.REGS[SR1] + CURRENT_LATCHES.REGS[SR2];
                }
                break;
            case 1: // AND
                if (addressing_mode) {
                    alu_val = CURRENT_LATCHES.REGS[SR1] & imm_val;
                } else {
                    alu_val = CURRENT_LATCHES.REGS[SR1] & CURRENT_LATCHES.REGS[SR2];
                }
                break;
            case 2: // XOR
                if (addressing_mode) {
                    alu_val = CURRENT_LATCHES.REGS[SR1] ^ imm_val;
                } else {
                    alu_val = CURRENT_LATCHES.REGS[SR1] ^ CURRENT_LATCHES.REGS[SR2];
                }
                break;
            case 3: // PASSA
                alu_val = CURRENT_LATCHES.REGS[SR1];
                break;
        }
    }
   
// SHF
    if (GetGATE_SHF(CURRENT_LATCHES.MICROINSTRUCTION)) {
        int bit5 = (CURRENT_LATCHES.IR >> 5) & 0x1;
        int bit4 = (CURRENT_LATCHES.IR >> 4) & 0x1;
        int amount4 = (CURRENT_LATCHES.IR & 0xF);
       
        if (bit4) {     // right
            if (bit5) { // rshfl
                int temp = CURRENT_LATCHES.REGS[SR1];
                for (int i = 0; i < amount4; i++) {
                    temp = temp >> 1;
                    temp = temp | ((temp >> 15) & 0x1) << 15;
                }
                shf_val = Low16bits(temp);
            }
            else { // rshfa
                int temp = CURRENT_LATCHES.REGS[SR1];
                int sign_bit = (temp >> 15) & 0x1; 
                for (int i = 0; i < amount4; i++) {
                    temp = temp >> 1;
                    temp = temp | 0 << 15;
                }
                shf_val = Low16bits(temp);
            }
        }
        else {  // lshf
            shf_val = CURRENT_LATCHES.REGS[SR1] << amount4;
        }
    }


// MARMUX
    if (GetGATE_MARMUX(CURRENT_LATCHES.MICROINSTRUCTION)) {
        if (MARMUX) {
            marmux_val = adder;
        } else {
            int signExtendedValue = signExtend(CURRENT_LATCHES.IR & 0xFF, 8);
            marmux_val = signExtendedValue << 1;
        }
    }

// MDR
    if (GetGATE_MDR(CURRENT_LATCHES.MICROINSTRUCTION)) { // load byte/word
        if (DATA_SIZE) {    // word
            mdr_val = CURRENT_LATCHES.MDR;
        }
        else { // byte
            if (CURRENT_LATCHES.MAR & 0x01) {
                int upperByte = (CURRENT_LATCHES.MDR >> 8) & 0xFF;
                mdr_val = signExtend(upperByte, 8);
            } else {
                int lowerByte = CURRENT_LATCHES.MDR & 0xFF;
                mdr_val = signExtend(lowerByte, 8);
            }
        }
    }

// PC
    if (GetLD_PC(CURRENT_LATCHES.MICROINSTRUCTION)) {
        if (PCMUX == 0) {
            pc_val = CURRENT_LATCHES.PC + 2;
        }
        else if (PCMUX == 1) {
            pc_val = BUS;
        }
        else if (PCMUX == 2) {
            pc_val = adder;
        }
    }


// ADDITIONAL 
// SPMUX        
   // returns SPMUX0 + SPMUX1
    if (GetGATE_SP(CURRENT_LATCHES.MICROINSTRUCTION)) {
        if (SPMUX == 0) {
            sp_val = CURRENT_LATCHES.USP; 
        }
        else if (SPMUX == 1) {  
            sp_val = CURRENT_LATCHES.SSP; 
        }
        else if (SPMUX == 2) {  // R6+2
            sp_val = signExtend(Low16bits(CURRENT_LATCHES.REGS[6]), 15) + 2;; 
        }
        else if (SPMUX == 3) {  // R6-2
            sp_val = signExtend(Low16bits(CURRENT_LATCHES.REGS[6]), 15) - 2;
        }
    }

//PSR  
    if (GetGATE_PSR(CURRENT_LATCHES.MICROINSTRUCTION)) {
        if (PSRMUX) {
            int psr_15 = (BUS >> 15) & 0x1; 
            psr_val = psr_15;
        } 
        else {
            psr_val = CURRENT_LATCHES.PSR; 
        }
    }

// VECMUX   
if (GetGATE_VEC(CURRENT_LATCHES.MICROINSTRUCTION)) {
    if (VECMUX) {
        // vec_val = (CURRENT_LATCHES.EXCV << 1) | 0x0200;
        vec_val = (CURRENT_LATCHES.INTV << 1) | 0x0200;
    } else {
        if (CURRENT_LATCHES.INT == 1) {
            vec_val = (CURRENT_LATCHES.INTV << 1) | 0x0200;
        }
        else {
            vec_val = (CURRENT_LATCHES.EXCV << 1) | 0x0200;
        }
        // vec_val = (CURRENT_LATCHES.INTV << 1) | 0x0200;    
    }
    // vec_val = (0x02 << 8) | (CURRENT_LATCHES.VEC << 1);
}

// PCDEC
if (GetGATE_PCDEC(CURRENT_LATCHES.MICROINSTRUCTION)) {
    pcdec_val = CURRENT_LATCHES.PC - 2; 
}

}
void drive_bus() {
    /*
    * Datapath routine for driving the bus from one of the 5 possible
    * tristate drivers.
    */  
    if (GetGATE_ALU(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = alu_val;
    }
    else if (GetGATE_SHF(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = shf_val;
    }
    else if (GetGATE_MARMUX(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = marmux_val;
    }
    else if (GetGATE_MDR(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = mdr_val;
    }
    else if (GetGATE_PC(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = CURRENT_LATCHES.PC;
    }
   
   /*Additional Gates: SP, VEC,PSR, PCDEC*/
    else if (GetGATE_SP(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = sp_val; 
    }
    else if (GetGATE_VEC(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = vec_val; 
    }
    else if (GetGATE_PSR(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = psr_val; 
    }
    else if (GetGATE_PCDEC(CURRENT_LATCHES.MICROINSTRUCTION)) {
        BUS = pcdec_val; 
    }    

    // None
    else { 
        BUS = 0;
    }
}

void latch_datapath_values() {
    /*
    * Datapath routine for computing all functions that need to latch
    * values in the data path at the end of this cycle.  Some values
    * require sourcing the bus; therefore, this routine has to come
    * after drive_bus.
    */     
   int excFlag = (flagException())
    && (CURRENT_LATCHES.STATE_NUMBER != 18)
    && (CURRENT_LATCHES.STATE_NUMBER != 32)
    && (CURRENT_LATCHES.STATE_NUMBER != 33)
    && (CURRENT_LATCHES.STATE_NUMBER != 26)
    && (CURRENT_LATCHES.STATE_NUMBER != 40)
    && (CURRENT_LATCHES.STATE_NUMBER != 45)
    && (CURRENT_LATCHES.STATE_NUMBER != 47)
    && (CURRENT_LATCHES.STATE_NUMBER != 46)
    && (CURRENT_LATCHES.STATE_NUMBER != 48)
    && (CURRENT_LATCHES.STATE_NUMBER != 50)
    && (CURRENT_LATCHES.STATE_NUMBER != 56)
    && (CURRENT_LATCHES.STATE_NUMBER != 58)
    && (CURRENT_LATCHES.STATE_NUMBER != 15)
    && (CURRENT_LATCHES.STATE_NUMBER != 11)
    && (CURRENT_LATCHES.STATE_NUMBER != 10)
    && (CURRENT_LATCHES.STATE_NUMBER != 41)
    && (CURRENT_LATCHES.STATE_NUMBER != 45)
    && (CURRENT_LATCHES.STATE_NUMBER != 35)
    ; 

    if (excFlag) { 

        NEXT_LATCHES.STATE_NUMBER = 11; 
        // NEXT_LATCHES.PC = CURRENT_LATCHES.PC - 2; 
        CURRENT_LATCHES.EXC = 1; 
        NEXT_LATCHES.PRIV = 0; 
        NEXT_LATCHES.PSR = CURRENT_LATCHES.PSR & 0xFFFF7FFF; 
        return; 

    }

    if (CURRENT_LATCHES.STATE_NUMBER == 51) {
        NEXT_LATCHES.PSR = CURRENT_LATCHES.MDR; 
    }


    if(GetLD_MAR(CURRENT_LATCHES.MICROINSTRUCTION)){
        NEXT_LATCHES.MAR = Low16bits(BUS);
    }
    if(GetLD_MDR(CURRENT_LATCHES.MICROINSTRUCTION)){
        if(GetMIO_EN(CURRENT_LATCHES.MICROINSTRUCTION)){
            NEXT_LATCHES.MDR = Low16bits(read_result);
        }else{
            if(GetDATA_SIZE(CURRENT_LATCHES.MICROINSTRUCTION)){
                NEXT_LATCHES.MDR = Low16bits(BUS);
            }else{
                NEXT_LATCHES.MDR = Low16bits(BUS & 0xFF);
            }
        }
    }
    if (GetLD_IR(CURRENT_LATCHES.MICROINSTRUCTION)) {
        NEXT_LATCHES.IR = Low16bits(BUS);
    }
    if (GetLD_BEN(CURRENT_LATCHES.MICROINSTRUCTION))
    {
        int N = (CURRENT_LATCHES.IR & 0x0800) >> 11;
        int Z = (CURRENT_LATCHES.IR & 0x0400) >> 10;
        int P = (CURRENT_LATCHES.IR & 0x0200) >> 9;

        NEXT_LATCHES.BEN = (N && CURRENT_LATCHES.N)||(Z && CURRENT_LATCHES.Z)||(P && CURRENT_LATCHES.P);
    }   
    if(GetLD_REG(CURRENT_LATCHES.MICROINSTRUCTION)){
        int dr; 
        // int getDRMUX = GetDRMUX(CURRENT_LATCHES.MICROINSTRUCTION); 
        int getDRMUX = (GetDRMUX1(CURRENT_LATCHES.MICROINSTRUCTION)<<1) + GetDRMUX(CURRENT_LATCHES.MICROINSTRUCTION);
        if (getDRMUX == 1)      dr = 7; // 111
        else if (getDRMUX == 0) dr = (CURRENT_LATCHES.IR >> 9) & 0x7;    // IR[11:9]
        else if (getDRMUX == 2) dr = 6; // 110                   
        NEXT_LATCHES.REGS[dr] = Low16bits(BUS);
    }
    if (GetLD_CC(CURRENT_LATCHES.MICROINSTRUCTION)) {
        int num = Low16bits(BUS);
        if (CURRENT_LATCHES.STATE_NUMBER == 51) {
            NEXT_LATCHES.PSR = num; 
        }
        // condition codes
        if (num & 0x8000) { // N - check msb
            NEXT_LATCHES.N = 1;
            NEXT_LATCHES.Z = 0;
            NEXT_LATCHES.P = 0;
            // psr
            NEXT_LATCHES.PSR &= 0x8000;
            NEXT_LATCHES.PSR |= 0x0004;
        }
        else if (num == 0) { // Z
            NEXT_LATCHES.N = 0;
            NEXT_LATCHES.Z = 1;
            NEXT_LATCHES.P = 0;
            // psr
            NEXT_LATCHES.PSR &= 0x8000;
            NEXT_LATCHES.PSR |= 0x0002;
        }
        else if (num > 0) { // P
            NEXT_LATCHES.N = 0;
            NEXT_LATCHES.Z = 0;
            NEXT_LATCHES.P = 1;
            // psr
            NEXT_LATCHES.PSR &= 0x8000;
            NEXT_LATCHES.PSR |= 0x0001;
        }
    }
    if (GetLD_PC(CURRENT_LATCHES.MICROINSTRUCTION)) {
        NEXT_LATCHES.PC = Low16bits(pc_val);
        // added
        if ((CURRENT_LATCHES.STATE_NUMBER == 58)||(CURRENT_LATCHES.STATE_NUMBER == 38)) {
            NEXT_LATCHES.PC = Low16bits(BUS);
        }
    }
    //ADDITIONAL
    // PRIV
    if (GetLD_PRIV(CURRENT_LATCHES.MICROINSTRUCTION)) {
        if (GetPSRMUX(CURRENT_LATCHES.MICROINSTRUCTION)) {
            NEXT_LATCHES.PRIV = (BUS & 0x8000) >> 15;
        } else {
            NEXT_LATCHES.PRIV = 0;
        }
    }


    if (CURRENT_LATCHES.STATE_NUMBER == 41) { 
        NEXT_LATCHES.MDR = CURRENT_LATCHES.PSR; 
        if ((global_INT == 1) || NEXT_LATCHES.EXC)
        NEXT_LATCHES.PRIV = 0; 
        NEXT_LATCHES.PSR = CURRENT_LATCHES.PSR & 0xFFFF7FFF; 
    }


    // VEC
    if (GetLD_VEC(CURRENT_LATCHES.MICROINSTRUCTION)) {
    //  if (GetVECMUX(CURRENT_LATCHES.MICROINSTRUCTION)) {
    //      NEXT_LATCHES.VEC = (CURRENT_LATCHES.EXCV << 1) | 0x0200;
    //   } else {
    //      NEXT_LATCHES.VEC = (CURRENT_LATCHES.INTV << 1) | 0x0200;
    //   }
        NEXT_LATCHES.VEC = Low16bits(BUS);
        if (global_INT == 1) {
            NEXT_LATCHES.VEC = 0x1; 
            global_INT = 0; 
        }
    }
    // SSP: SSP = R6
    if (GetLD_SAVESSP(CURRENT_LATCHES.MICROINSTRUCTION)) {
        NEXT_LATCHES.SSP = Low16bits(CURRENT_LATCHES.REGS[6]);
   }
   // USP: USP = R6
   if (GetLD_SAVEUSP(CURRENT_LATCHES.MICROINSTRUCTION)) { 
        NEXT_LATCHES.USP = Low16bits(CURRENT_LATCHES.REGS[6]);
   }

   
}
