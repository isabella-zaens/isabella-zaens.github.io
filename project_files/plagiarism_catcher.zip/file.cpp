#include "file.h"


File::File() {
    this->fileName = "empty";
    this->processedText = "empty";
    sequences[0] = {};
}

string File::getFileName() {
    return fileName;
}

void File::setFileName(string &fileName) {
    this->fileName = fileName;
}

unordered_map<int, string> File::getSequences() {
    return sequences;
}


void File::setProcessedText(string str) {
    this->processedText = str;
}

vector<string> File::split(string text) {
    vector<string> words;
    string word = "";
    for (char c: text) {
        if (c != ' ') {
            word += c;
        } else {
            if (!word.empty()) {
                words.push_back(word);
                word = "";
            }
        }
    }
    // Add the last word
    if (!word.empty()) {
        words.push_back(word);
    }
    return words;
}

void File::generatePSequencies(int p) {
    vector<string> chunks;
    // Split the text into words
    vector<string> words = split(this->processedText);

    // Iterate through words and push to vector
    for (int i = 0; i < static_cast<int>(words.size() - p + 1); i++) {
        string str = "";
        for (int j = 0; j < p; j++) {
            str += words[i + j];
        }
        chunks.push_back(str);
    }
    // populating sequences
    int i = 0;
    for (i = 0; i < static_cast<int>(chunks.size()); i++) {
        string str = chunks.at(i);
        int index = hashString(chunks.at(i));
        sequences.insert({index, chunks.at(i)});
    }
}

void File::emptyFile() {
    this->fileName = "";
    this->processedText = "";
    sequences.clear();
}

int File::hashString(string str) {
    int index = 0;

    for (int i = 0; i < static_cast<int>(str.size()); i++) {
        index = index * 101 + str[i];
    }
    return index % 1000000;
}