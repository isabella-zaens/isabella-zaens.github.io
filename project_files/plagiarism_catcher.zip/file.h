#ifndef CHEATERS_IPZ65_FILE_H
#define CHEATERS_IPZ65_FILE_H

#include <string>
#include <vector>
#include <unordered_map>

using namespace std;

class File {
private:
    string fileName;
    string processedText;
    unordered_map<int, string> sequences;

public:
    File();

    string getFileName();

    unordered_map<int, string> getSequences();

    void setFileName(string &fileName);

    void setProcessedText(string str);

    vector<string> split(string text);

    void generatePSequencies(int p);

    void emptyFile();

    int hashString(string str);

};


#endif //CHEATERS_IPZ65_FILE_H
