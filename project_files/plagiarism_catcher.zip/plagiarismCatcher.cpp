#include <sys/types.h>
#include <dirent.h>
#include <errno.h>

#include <iostream>
#include <fstream>
// #include <filesystem>
#include <vector>
#include <string>

#include "processFile.h"
#include "file.h"

using namespace std;

int countColissions(unordered_map<int, string> f1, File f2);

struct printOrder {
    int col, f1, f2;
};

int main(int argc, char *argv[]) {
    // checking if there are more than two arguments
    if (argc < 2) {
        cout << "ERROR: Three arguments are needed: directory name, p, and m" << endl;
        return (0);
    }

    // for testing on Linux
    string dir = argv[1]; // name of directory
    int p = atoi(argv[2]);
    int m = atoi(argv[3]);

//    // for testing in CLion
//    int p = 6;
//    int m = 200;
//    string dir = "sm_doc_set";

    vector<string> files = vector<string>();
    getdir(dir, files);
    int size = files.size();

    // holds file name, processedText, and sequences
    vector<File> fileDirectory;

    // prepending directory name
    string prepend = dir;
    prepend.append("/");

    // processing all files and creating p-sequences
    File f;
    for (int i = 2; i < static_cast<int>(size); i++) {
        string fileName = files[i];

        // storing file name into filesDirectory vector
        f.setFileName(fileName);
        fileName.insert(0, prepend);

        // storing processed file into filesDirectory vector
        f.setProcessedText(processFile(fileName));
        f.generatePSequencies(p);
        fileDirectory.push_back(f);
        f.emptyFile();
    }

    vector<printOrder> print;
    unordered_map<int, string> hashtable, seq;
    for (int i = 0; i < static_cast<int>(fileDirectory.size()); i++) {
        for (int j = i+1; j < static_cast<int>(fileDirectory.size()); j++) {
            unordered_map<int, string> f1seq = fileDirectory.at(i).getSequences();
            int count = countColissions(f1seq, fileDirectory.at(j));
            if (count >= m) {
                printOrder p = {count, i, j};
                print.push_back(p);
            }
        }
    }

    // sorting vector for printing
    for (int i = 0; i < static_cast<int>(print.size()); i++) {
        // Iterate over all the elements after the current element.
        for (int j = i + 1; j < static_cast<int>(print.size()); j++) {
            // If the current element is less than the element after it, swap them.
            if (print.at(i).col < print.at(j).col) {
                int tempCol = print.at(i).col;
                int tempf1 = print.at(i).f1;
                int tempf2 = print.at(i).f2;

                print.at(i).col = print.at(j).col;
                print.at(i).f1 = print.at(j).f1;
                print.at(i).f2 = print.at(j).f2;

                print.at(j).col = tempCol;
                print.at(j).f1 = tempf1;
                print.at(j).f2 = tempf2;
            }
        }
    }

    // print output
    for (int i =0 ; i < static_cast<int>(print.size()); i++) {
        if (print.at(i).col >= m) {
            cout << print.at(i).col << ": " << fileDirectory.at(print.at(i).f1).getFileName() << ", " << fileDirectory.at(print.at(i).f2).getFileName()  << endl;
        }
    }

    return 0;
}

int countColissions(unordered_map<int, string> f1seq, File f2) {
    unordered_map<int, string> f2seq = f2.getSequences();
    int col = 0;
    for (auto iterf1 = f1seq.begin(); iterf1 != f1seq.end(); iterf1++) {
        for (auto iterf2 = f2seq.begin(); iterf2 != f2seq.end(); iterf2++) {
            if (iterf1->first == iterf2->first) {
                col++;
            }
        }
    }
    return col;
}
