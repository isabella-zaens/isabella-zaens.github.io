#ifndef CHEATERS_IPZ65_PROCESSFILE_H
#define CHEATERS_IPZ65_PROCESSFILE_H

#include <string>
#include <vector>

using namespace std;

int getdir(string dir, vector<string> &files) {
    DIR *dp;
    struct dirent *dirp;
    if ((dp = opendir(dir.c_str())) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {
        files.push_back(string(dirp->d_name));
    }
    closedir(dp);
    return 0;
}

bool is_letter(char ch) {
    // Check if it is an uppercase letter
    if (ch >= 'A' && ch <= 'Z') {
        return true;
    }
        // Check if it is a lowercase letter
    else if (ch >= 'a' && ch <= 'z') {
        return true;
    }
        // The character is not a letter.
    else {
        return false;
    }
}

char to_lower(char ch) {
    // If the character is uppercase, convert it to lowercase.
    if (ch >= 'A' && ch <= 'Z') {
        return ch + ('a' - 'A');
    }
        // The character is already lowercase.
    else {
        return ch;
    }
}

string processFile(const string& filename) {
    string str;
    ifstream file(filename);

    if (file.is_open()) {
        char c;
        while (file.get(c)) {
            // Checking if it is a letter
            if (is_letter(c)) {
                c = to_lower(c);
                str += c;
            }
            // Checking if it is punctuation
            else if (c == ' ' || c == '\'') {
                str += c;
            }
            // Checking if it is a number
            if (c >= '0' && c <= '9') {
                str += c;
            }
        }
        file.close();
    }
    return str;
}

#endif //CHEATERS_IPZ65_PROCESSFILE_H
