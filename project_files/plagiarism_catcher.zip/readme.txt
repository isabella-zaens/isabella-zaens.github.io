Isabella Nicole Zaens
8/10/23

Plagiarism Catcher 
This program checks for plagiarism in a directory of text files. 
The plagiarism detection program takes three command line parameters: the name of the directory, p (the length of the word sequences), and m (the plagiarism suspicion index). The program first parses through all the files in the directory, converting all uppercase letters to lower case letters and removing all punctuation and special characters, except for apostrophes. It then creates p-sized chunks of texts from each file and stores them in a hashtable. The program also creates a vector that holds the file names and the p-sized chunks of texts for each file.

After parsing all of the files in the directory, the program compares the chunks of texts from all the files, in pairs. It counts the number of similar chunks of texts using the hash index. If the number of collisions found from each pair of files exceeds m, the plagiarism suspicion index, the program will push the number of collisions and the number of both files into a vectory array. 

Once the program has finished parsing through all the possible combinations of the files in the directory, the vectory of collisions is then sorted in decreasing collission size. The output statement is then printed by looping through the vector of collisions and printing the number of collisions and file names.

How to run:
- Unzip the contents into a linux directory, then use the "make" command, and the makefile will compile and link the program.
  Make sure your desired picture .txt file is in the same directory.
  To run the program, use the command
      ./PlagiarismCatcher directory_name p m

where directory_name is the name of the file directory that holds the text files, p is the length of the word sequence, and m is the plagiarism suspicion index
